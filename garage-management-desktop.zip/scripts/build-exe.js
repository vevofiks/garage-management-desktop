const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

console.log('Cleaning build directory...');
const distDir = path.join(__dirname, '../dist');
if (fs.existsSync(distDir)) {
  fs.rmSync(distDir, { recursive: true, force: true });
}

console.log('Building Next.js app...');
execSync('npm run build', { stdio: 'inherit' });

console.log('Copying static assets to standalone folder...');
const standaloneDir = path.join(__dirname, '../.next/standalone');
const publicDir = path.join(__dirname, '../public');
const staticDir = path.join(__dirname, '../.next/static');

fs.cpSync(publicDir, path.join(standaloneDir, 'public'), { recursive: true });
fs.cpSync(staticDir, path.join(standaloneDir, '.next/static'), { recursive: true });

const buildIdFile = path.join(__dirname, '../.next/BUILD_ID');
if (fs.existsSync(buildIdFile)) {
  fs.cpSync(buildIdFile, path.join(standaloneDir, '.next/BUILD_ID'));
}

console.log('Ready for electron-builder.');

const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const http = require('http');
const fs = require('fs');

// Prevent uncaught exceptions from popping up unhandled error dialogs in production
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception in Main Process:', err);
});

const isDev = !app.isPackaged;

function loadAppUrl(win, url) {
  let attempts = 0;
  const poll = () => {
    attempts++;
    http.get(url, (res) => {
      win.loadURL(url);
    }).on('error', () => {
      if (attempts < 30) {
        setTimeout(poll, 300);
      } else {
        win.loadURL(url);
      }
    });
  };
  poll();
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1280,
    height: 800,
    icon: path.join(__dirname, '../public/app-logo.png'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  if (isDev) {
    // In dev: load the Next.js dev server (started separately via concurrently)
    win.loadURL('http://localhost:3000');
    win.webContents.openDevTools();
  } else {
    // In production: Next.js runs in-process inside Electron main process
    process.env.APP_DATA_DIR = app.getPath('userData');
    process.env.PORT = '3000';
    process.env.NODE_ENV = 'production';
    process.env.ELECTRON_RUN_AS_NODE = '1';
    process.env.HOSTNAME = '0.0.0.0';

    try {
      const unpackedServerPath = path.join(__dirname, '../../app.asar.unpacked/.next/standalone/server.js');
      const defaultServerPath = path.join(__dirname, '../.next/standalone/server.js');
      const nextServerPath = fs.existsSync(unpackedServerPath) ? unpackedServerPath : defaultServerPath;
      
      require(nextServerPath);
    } catch (err) {
      console.error('Failed to start Next.js standalone server:', err);
    }

    loadAppUrl(win, 'http://localhost:3000');
  }
}

// Renderer calls window.electronAPI.printInvoice() (exposed via preload.js)
ipcMain.handle('print-invoice', (event) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  win?.webContents.print({ silent: false, printBackground: true, pageSize: 'A4' });
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});

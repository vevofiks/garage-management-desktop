/**
 * electron/preload.js
 *
 * Secure bridge between Electron's main process and the Next.js renderer (UI).
 * Use `contextBridge.exposeInMainWorld` here to safely expose specific
 * Electron/Node APIs to the frontend — never enable nodeIntegration.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('electronAPI', {
  printInvoice: () => ipcRenderer.invoke('print-invoice'),
});

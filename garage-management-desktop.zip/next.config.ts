import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Tell Next.js that source files live in src/
  // (App Router auto-detects src/app, but being explicit is safer)

  // For production packaging (step 9), switch to:
  output: 'standalone',
};

export default nextConfig;
